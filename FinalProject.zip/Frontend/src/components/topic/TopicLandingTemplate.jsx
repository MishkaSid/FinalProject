// All comments in English. All user-facing text in Hebrew (RTL).
import React, { useEffect, useMemo, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import styles from "./topicLanding.module.css";
import { FiBook, FiVideo, FiTarget } from "react-icons/fi";

/** Convert a YouTube full URL or raw ID into an embeddable URL */
function toYoutubeEmbed(urlOrId) {
  if (!urlOrId) return null;
  if (!/^https?:\/\//i.test(urlOrId)) {
    return `https://www.youtube.com/embed/${urlOrId}`;
  }
  try {
    const u = new URL(urlOrId);
    if (u.hostname.includes("youtu.be")) {
      return `https://www.youtube.com/embed/${u.pathname.replace("/", "")}`;
    }
    const id = u.searchParams.get("v");
    if (id) return `https://www.youtube.com/embed/${id}`;
    if (u.pathname.includes("/embed/")) return urlOrId;
  } catch {}
  return urlOrId;
}

/** Map backend videos into 1 intro + 3 by levels (fallback if no Difficulty) */
function arrangeVideos(videos) {
  if (!Array.isArray(videos) || videos.length === 0)
    return { intro: null, levels: [] };

  const byKey = { intro: null, easy: null, medium: null, exam: null };
  videos.forEach((v) => {
    const key = (v.Difficulty || "").toLowerCase();
    if (["intro", "easy", "medium", "exam"].includes(key) && !byKey[key]) {
      byKey[key] = v;
    }
  });

  const fallback = () => {
    const [first, ...rest] = videos;
    const levels = rest.slice(0, 3);
    return {
      intro: first || null,
      levels: levels.map((v, i) => ({
        ...v,
        Difficulty: ["easy", "medium", "exam"][i] || "easy",
      })),
    };
  };

  if (!byKey.intro) return fallback();
  const levels = ["easy", "medium", "exam"]
    .map((k) => byKey[k])
    .filter(Boolean);
  if (levels.length < 3) return fallback();
  return { intro: byKey.intro, levels };
}

export default function TopicLandingTemplate() {
  const { topicId } = useParams();
  const navigate = useNavigate();

  const [loading, setLoading] = useState(true);
  const [topic, setTopic] = useState(null);
  const [videos, setVideos] = useState([]);
  const [error, setError] = useState(null);

  // IMPORTANT:
  // - We fetch ONLY from the server; no hard-coded descriptions.
  // - On error, we show a user-facing error and DO NOT inject default content.
  useEffect(() => {
    let cancelled = false;

    async function load() {
      try {
        setLoading(true);
        setError(null);

        // getTopicInfo — uses tables: topic, course (as you said)
        const tRes = await fetch(
          `http://localhost:5000/api/practice-dashboard/topic/${topicId}`
        );

        if (!tRes.ok) {
          const errText = await tRes.text().catch(() => "");
          throw new Error(`Topic request failed: ${tRes.status} ${errText}`);
        }
        const tJson = await tRes.json();

        // getPracticeVideos (optional to display)
        const vRes = await fetch(
          `http://localhost:5000/api/practice-dashboard/videos/${topicId}`
        );

        // videos may be optional; if endpoint fails we still show the page
        let vJson = [];
        if (vRes.ok) {
          vJson = await vRes.json();
        }

        if (!cancelled) {
          setTopic(tJson);
          setVideos(Array.isArray(vJson) ? vJson : []);
        }
      } catch (e) {
        if (!cancelled) {
          console.error("Landing load error:", e);
          setError(
            "שגיאה בטעינת הנתונים מהשרת. נסו לרענן את הדף או לחזור מאוחר יותר."
          );
        }
      } finally {
        if (!cancelled) setLoading(false);
      }
    }

    load();
    return () => {
      cancelled = true;
    };
  }, [topicId]);

  // Build Hebrew strings strictly from DB, with minimal fallback
  const subjectName = useMemo(() => {
    if (!topic) return "";
    const course = topic.CourseName || "קורס";
    const name = topic.TopicName || "נושא";
    return `${course} – ${name}`;
  }, [topic]);

  const subjectDescription = useMemo(() => {
    if (!topic) return "";
    // CRITICAL: prefer DB description; do NOT override with generic text if exists
    if (
      topic.TopicDescription &&
      String(topic.TopicDescription).trim().length > 0
    ) {
      return String(topic.TopicDescription).trim();
    }
    return "אין תיאור לנושא זה.";
  }, [topic]);

  const { intro, levels } = useMemo(() => arrangeVideos(videos), [videos]);

  const handlePractice = () => {
    navigate(`/student/practice-questions/${topicId}`);
  };

  if (loading) {
    return (
      <div className={styles.container}>
        <div className={styles.loadingBox} role="status" aria-live="polite">
          <div className={styles.spinner} />
          <p>טוען תוכן…</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className={styles.container}>
        <div className={styles.errorBox} role="alert">
          <p>{error}</p>
        </div>
      </div>
    );
  }

  return (
    <div className={styles.container}>
      {/* Hero: big colorful title with animated background */}
      <header className={styles.hero}>
        <div className={styles.heroInner}>
          <h1 className={styles.heroTitle}>{subjectName}</h1>
        </div>
      </header>

      {/* Separate description card (pulled from DB) */}
      <section
        className={styles.descSection}
        aria-labelledby="topic-desc-title"
      >
        <h2 id="topic-desc-title" className={styles.visuallyHidden}>
          תיאור הנושא
        </h2>
        <div className={styles.descCard}>
          <p className={styles.descText}>{subjectDescription}</p>
        </div>
      </section>

      {/* Intro video */}
      <section className={styles.section}>
        <h2 className={styles.sectionTitle}>
          <span aria-hidden="true" className={styles.titleIcon}>
            <FiVideo />
          </span>
          סרטון פתיחה
        </h2>
        <article className={styles.introCard}>
          <div className={styles.introFrame}>
            {intro?.VideoUrl ? (
              <iframe
                className={styles.videoFrame}
                src={toYoutubeEmbed(intro.VideoUrl)}
                title={intro.VideoTopic || "סרטון פתיחה"}
                loading="lazy"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
              />
            ) : (
              <div className={styles.placeholder}>אין כתובת וידאו להצגה</div>
            )}
          </div>
          <div className={styles.introInfo}>
            <h3 className={styles.videoTitle}>
              {intro?.VideoTopic || "סרטון פתיחה"}
            </h3>
            <p className={styles.videoDesc}>{topic?.TopicName || ""}</p>
          </div>
        </article>
      </section>

      {/* 3 videos by difficulty */}
      <section className={styles.section}>
        <h2 className={styles.sectionTitle}>
          <span aria-hidden="true" className={styles.titleIcon}>
            <FiTarget />
          </span>
          סרטונים לפי רמה
        </h2>
        <div className={styles.levelsGrid}>
          {["קל", "בינוני", "רמת מבחן"].map((label, i) => {
            const v = levels[i];
            return (
              <article key={i} className={styles.levelCard}>
                <div className={styles.levelHeader}>
                  <span className={styles.levelBadge}>{label}</span>
                </div>
                <div className={styles.levelFrame}>
                  {v?.VideoUrl ? (
                    <iframe
                      className={styles.videoFrame}
                      src={toYoutubeEmbed(v.VideoUrl)}
                      title={v.VideoTopic || label}
                      loading="lazy"
                      allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                      allowFullScreen
                    />
                  ) : (
                    <div className={styles.placeholder}>
                      אין כתובת וידאו להצגה
                    </div>
                  )}
                </div>
                <div className={styles.levelInfo}>
                  <h3 className={styles.videoTitle}>
                    {v?.VideoTopic || `סרטון ${label}`}
                  </h3>
                </div>
              </article>
            );
          })}
        </div>
      </section>

      {/* CTA */}
      <div className={styles.ctaRow}>
        <button className={styles.ctaBtn} onClick={handlePractice}>
          <FiBook aria-hidden="true" />
          <span>עבור לתרגול שאלות</span>
        </button>
      </div>
    </div>
  );
}
